<!DOCTYPE html>
<html>
<head>
    <title>New User</title>
</head>
<body>

<h1>Add New User</h1>

<?php if (isset($validation)): ?>
    <?= $validation->listErrors() ?>
<?php endif; ?>

<form action="<?= base_url('users/create') ?>" method="post">

    <label>Username:</label><br>
    <input type="text" name="username" value="<?= esc(old('username')) ?>"><br><br>

    <label>Full Name:</label><br>
    <input type="text" name="full_name" value="<?= esc(old('full_name')) ?>"><br><br>

    <label>Email:</label><br>
    <input type="email" name="email" value="<?= esc(old('email')) ?>"><br><br>

    <label>Password:</label><br>
    <input type="password" name="password"><br><br>

    <label>Role:</label><br>
    <input type="text" name="role" value="<?= esc(old('role')) ?>"><br><br>

    <button type="submit">Save User</button>
</form>

<br>
<a href="<?= base_url('users') ?>">Back to Users</a>

</body>
</html>