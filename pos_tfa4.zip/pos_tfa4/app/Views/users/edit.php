<!DOCTYPE html>
<html>
<head>
    <title>Edit User</title>
</head>
<body>

<h1>Edit User</h1>

<?php if (isset($validation)): ?>
    <?= $validation->listErrors() ?>
<?php endif; ?>

<form action="<?= base_url('users/update/' . $user['id']) ?>"
      method="post"
      enctype="multipart/form-data">

    <label>Username:</label><br>
    <input type="text" name="username"
           value="<?= esc(old('username', $user['username'])) ?>"><br><br>

    <label>Full Name:</label><br>
    <input type="text" name="full_name"
           value="<?= esc(old('full_name', $user['full_name'])) ?>"><br><br>

    <label>Email:</label><br>
    <input type="email" name="email"
           value="<?= esc(old('email', $user['email'] ?? '')) ?>"><br><br>

    <label>New Password:</label><br>
    <input type="password" name="password">
    <small>Leave blank to keep the current password.</small><br><br>

    <label>Role:</label><br>
    <input type="text" name="role"
           value="<?= esc(old('role', $user['role'] ?? '')) ?>"><br><br>
           
    <label>Avatar:</label><br>
    <input type="file" name="avatar" accept=".jpg,.jpeg,.png"><br>
    <small>JPG or PNG only, maximum 2MB.</small><br><br>

    <button type="submit">Update User</button>
</form>

<br>
<a href="<?= base_url('users') ?>">Back to Users</a>

</body>
</html>