<?php

use CodeIgniter\Router\RouteCollection;

/** @var RouteCollection $routes */

$routes->get('/', 'Home::index');

$routes->get('login', 'Auth::login');
$routes->post('login', 'Auth::attemptLogin');
$routes->get('logout', 'Auth::logout');

$routes->get('customers', 'CustomerAccounts::index', ['filter' => 'auth']);
$routes->get('customers/new', 'CustomerAccounts::newCustomer', ['filter' => 'auth']);
$routes->post('customers/create', 'CustomerAccounts::create', ['filter' => 'auth']);
$routes->get('customers/edit/(:num)', 'CustomerAccounts::edit/$1', ['filter' => 'auth']);
$routes->post('customers/update/(:num)', 'CustomerAccounts::update/$1', ['filter' => 'auth']);

$routes->get('users', 'UserAccounts::index', ['filter' => 'auth']);
$routes->get('users/new', 'UserAccounts::newUser', ['filter' => 'auth']);
$routes->post('users/create', 'UserAccounts::create', ['filter' => 'auth']);
$routes->get('users/edit/(:num)', 'UserAccounts::edit/$1', ['filter' => 'auth']);
$routes->post('users/update/(:num)', 'UserAccounts::update/$1', ['filter' => 'auth']);