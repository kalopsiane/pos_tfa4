<?php

namespace App\Controllers;

use App\Models\UserModel;

class UserAccounts extends BaseController
{
    public function index()
    {
        $userModel = new UserModel();

        $data['users'] = $userModel->findAll();

        return view('user_accounts', $data);
    }

    public function newUser()
    {
        return view('users/new');
    }

    public function create()
    {
        $rules = [
            'username' => 'required|max_length[50]|is_unique[users.username]',
            'full_name' => 'required|max_length[100]',
            'email'    => 'permit_empty|valid_email|max_length[100]',
            'password' => 'permit_empty|max_length[255]',
            'role'     => 'permit_empty|max_length[30]',
        ];

        if (!$this->validate($rules)) {
            return view('users/new', [
                'validation' => $this->validator
            ]);
        }

        $userModel = new UserModel();

        $userModel->insert([
            'username'   => $this->request->getPost('username'),
            'full_name'  => $this->request->getPost('full_name'),
            'email'      => $this->request->getPost('email'),
            'password'   => $this->request->getPost('password'),
            'role'       => $this->request->getPost('role'),
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        return redirect()->to(base_url('users'));
    }

    public function edit($id)
    {
        $userModel = new UserModel();
        $user = $userModel->find($id);

        if (!$user) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        return view('users/edit', [
            'user' => $user
        ]);
    }

    public function update($id)
{
    $userModel = new UserModel();

    $rules = [
        'username'  => 'required|max_length[50]|is_unique[users.username,id,' . $id . ']',
        'full_name' => 'required|max_length[100]',
        'email'     => 'permit_empty|valid_email|max_length[100]',
        'password'  => 'permit_empty|max_length[255]',
        'role'      => 'permit_empty|max_length[30]',
    ];

    $avatar = $this->request->getFile('avatar');

    if ($avatar && $avatar->getError() !== UPLOAD_ERR_NO_FILE) {
        $rules['avatar'] = [
            'is_image[avatar]',
            'mime_in[avatar,image/jpg,image/jpeg,image/png]',
            'max_size[avatar,2048]'
        ];
    }

    if (!$this->validate($rules)) {
        return view('users/edit', [
            'user'       => $userModel->find($id),
            'validation' => $this->validator
        ]);
    }

    $data = [
        'username'  => $this->request->getPost('username'),
        'full_name' => $this->request->getPost('full_name'),
        'email'     => $this->request->getPost('email'),
        'role'      => $this->request->getPost('role'),
    ];

    $password = $this->request->getPost('password');

    if (!empty($password)) {
        $data['password'] = $password;
    }

    if ($avatar && $avatar->isValid() && !$avatar->hasMoved()) {
        $filename = $avatar->getRandomName();
        $uploadPath = FCPATH . 'uploads/avatars/';

        service('image')
            ->withFile($avatar->getTempName())
            ->fit(120, 120, 'center')
            ->save($uploadPath . $filename);

        $data['avatar'] = $filename;
    }

    $userModel->update($id, $data);

    return redirect()->to(base_url('users'));
}
}